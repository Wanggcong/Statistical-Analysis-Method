# statistics-hw

My statistics homework. Written in Scala.

Solutions for chapter 1 is located in `src/main/scala/net/zelinf/statisticshw/ch01`

Each of object `Problem1` to `Problem3` contains a main method.
You must pass the following VM parameters to run the program.

```
-Djava.library.path=$MATLAB_HOME/bin/glnxa64:$MATLAB_HOME/sys/os/glnxa64
```
Replace `$MATLAB_HOME` to your matlab installation root