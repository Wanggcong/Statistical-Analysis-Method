package net.zelinf.statisticshw.ch01
import org.scalatest.FunSpec
import impl.Plot
import MatlabHelper.engine

class PlotTest extends FunSpec {

  describe("histogram") {
    it("renders without error") {
      Plot.showHistogram(Array[Double](1, 1, 2, 3, 2, 4))
    }
  }
}
