package net.zelinf.statisticshw.ch01
import org.scalatest.FunSpec
import MatlabHelper.engine
import impl.BasicStat.BasicStatOps

class BasicStatTest extends FunSpec {

  describe("kurtosis") {
    it("returns a value") {
      val actual = Vector[Double](1, 2, 3).kurtosis
      assert(math.abs(actual - 1.5) < 0.01)
    }
  }
}
