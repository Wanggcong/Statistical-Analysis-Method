package net.zelinf.statisticshw.ch01

import org.scalatest.FunSpec

import impl.Correlation
import MatlabHelper.engine

class CorrTest extends FunSpec {

  describe("pearson") {
    it("should return pearson coef and p-val") {
      val xs: Array[Double] = Array(1, 2, 3, 4)
      val ys: Array[Double] = Array(2, 3, 4, 5)
      val result = Correlation.pearson(List((1, 2), (2, 3), (3, 4), (4, 5)))
      assert(result._1 === 1.0)
      assert(result._2 === 0.0)
    }
  }

  describe("spearman") {
    val result = Correlation.spearman(List((1, 2), (2, 3), (3, 4), (4, 5)))
  }
}
