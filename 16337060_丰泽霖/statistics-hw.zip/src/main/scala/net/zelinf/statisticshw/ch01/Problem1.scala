package net.zelinf.statisticshw.ch01
import impl.BasicStat._
import MatlabHelper.engine

object Problem1 {

  def main(args: Array[String]): Unit = {
    val csvReader = CSVHelper.readerFromFileInClasspath("000001.csv", getClass)
    val prices = CSVHelper.prices(csvReader.toStreamWithHeaders)

    println(s"平均数:\t${prices.mean}")
    println(s"中位数:\t${prices.median}")
    println(s"0.25分位数:\t${prices.quarterLowerQuant}")
    println(s"0.75分位数:\t${prices.quarterUpperQuant}")
    println(s"方差:\t${prices.variance}")
    println(s"标准差: \t${prices.stdDeviation}")
    println(s"变异系数：\t${prices.cv}%")
    println(s"极差:\t${prices.range}")
    println(s"四分位极差：\t${prices.quarterQuantRange}")
    println(s"偏度：\t${prices.skewness}")
    println(s"峰度：\t${prices.kurtosis}")

    csvReader.close()
  }
}
