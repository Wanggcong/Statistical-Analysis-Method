package net.zelinf.statisticshw.ch01.impl
import com.mathworks.engine.MatlabEngine
import net.zelinf.statisticshw.ch01.MatlabHelper

object Plot {

  def showHistogram(
    xs: IndexedSeq[Double]
  )(implicit engine: MatlabEngine): Unit = {
    MatlabHelper.newFigureWindow()
    engine.feval("histogram", xs.toArray)
  }

  def showQQPlot(
    xs: IndexedSeq[Double]
  )(implicit engine: MatlabEngine): Unit = {
    MatlabHelper.newFigureWindow()
    engine.feval("qqplot", xs.toArray)
  }
}
