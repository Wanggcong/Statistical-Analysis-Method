package net.zelinf.statisticshw.ch01
import java.util.concurrent.atomic.AtomicInteger

import com.mathworks.engine.MatlabEngine
import com.mathworks.matlab.types.Complex

object MatlabHelper {

  implicit lazy val engine: MatlabEngine = {
    Runtime.getRuntime.addShutdownHook(new Thread(() => {
      closeEngine()
    }))
    if (MatlabEngine.findMatlab().isEmpty)
      MatlabEngine.startMatlab()
    else
      MatlabEngine.connectMatlab()
  }

  def withEngine[U](f: MatlabEngine => U): U = f(engine)

  def closeEngine(): Unit = engine.close()

  def newFigureWindow(): Unit = {
    val n = figureWindowId.getAndAdd(1)
    engine.feval("figure", new Complex(n, 0))
  }

  private val figureWindowId: AtomicInteger = new AtomicInteger(1)
}
