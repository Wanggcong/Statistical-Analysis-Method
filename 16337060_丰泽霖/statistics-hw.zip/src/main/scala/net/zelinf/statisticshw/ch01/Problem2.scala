package net.zelinf.statisticshw.ch01
import MatlabHelper.engine
import impl.Plot

import scala.io.StdIn

object Problem2 {

  def main(args: Array[String]): Unit = {
    val csvReader = CSVHelper.readerFromFileInClasspath("000006.csv", getClass)
    val data = csvReader.toStreamWithHeaders
    val prices = CSVHelper.prices(data)
    Plot.showHistogram(prices)
    Plot.showQQPlot(prices)

    val diff = prices.drop(1).zip(prices).map(tup => tup._1 - tup._2)
    Plot.showHistogram(diff)
    Plot.showQQPlot(diff)

    println("Press RETURN to exit...")
    StdIn.readLine()
  }
}
