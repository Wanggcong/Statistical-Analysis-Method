package net.zelinf.statisticshw.ch01
import java.io.InputStreamReader

import com.github.tototoshi.csv.CSVReader

object CSVHelper {

  def readerFromFileInClasspath(file: String, clazz: Class[_]): CSVReader = {
    CSVReader.open(new InputStreamReader(clazz.getResourceAsStream(file)))
  }

  def column(csvData: Seq[Map[String, String]],
             columnName: String): IndexedSeq[Double] =
    csvData
      .map(m => m(columnName))
      .map(s => s.toDouble)
      .toIndexedSeq

  def prices(csvData: Seq[Map[String, String]]): IndexedSeq[Double] = {
    val high = CSVHelper.column(csvData, "high")
    val low = CSVHelper.column(csvData, "low")
    high.zip(low).map(tup => (tup._1 + tup._2) / 2)
  }
}
