package net.zelinf.statisticshw.ch01.impl
import com.mathworks.engine.MatlabEngine

object Correlation {

  def pearson(
    values: Seq[(Double, Double)]
  )(implicit engine: MatlabEngine): (Double, Double) = {
    val xs: Array[Double] = values.map(_._1).toArray
    val ys: Array[Double] = values.map(_._2).toArray
    val results: Array[Any] = engine.feval(2, "corrcoef", xs, ys)
    (to2DArray(results(0))(0)(1), to2DArray(results(1))(0)(1))
  }

  private def to2DArray(x: Any): Array[Array[Double]] = {
    x.asInstanceOf[Array[Array[Double]]]
  }

  /**
    * Returns spearman coefficient and p-val in tuple
    *
    * @param values Two vectors, zipped together
    * @param engine the matlab engine
    * @return (Spearman coefficient, pval)
    */
  def spearman(
    values: Seq[(Double, Double)]
  )(implicit engine: MatlabEngine): (Double, Double) = {
    val xs: Array[Array[Double]] =
      values.map(_._1).map(x => Array[Double](x)).toArray
    val ys: Array[Array[Double]] =
      values.map(_._2).map(y => Array[Double](y)).toArray

    val result: Array[Any] =
      engine.feval(2, "corr", xs, ys, "Type", "Spearman")
    (result(0).asInstanceOf[Double], result(1).asInstanceOf[Double])
  }
}
