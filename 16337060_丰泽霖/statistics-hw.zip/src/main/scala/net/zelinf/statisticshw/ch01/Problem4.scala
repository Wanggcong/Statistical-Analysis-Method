package net.zelinf.statisticshw.ch01

import java.io.{File, FilenameFilter}
import java.time.{LocalDate, LocalTime}

import net.zelinf.statisticshw.ch01.impl.Correlation
import MatlabHelper.engine
import com.github.tototoshi.csv.CSVReader

import scala.concurrent.{Await, Future}
import scala.concurrent.ExecutionContext.Implicits.global
import cats.implicits._

import scala.concurrent.duration.Duration

object Problem4 {

  type CorrMapping = ((String, String), ((Double, Double), (Double, Double)))

  def main(args: Array[String]): Unit = {
    println("Begin time: " + LocalTime.now())
    val csvFiles = listCSVFiles()
    val stockIds: Vector[String] =
      csvFiles.toVector.map(f => f.getName.stripSuffix(".csv"))
    val stocks: IndexedSeq[Map[LocalDate, Double]] = readStocks(csvFiles)

    val matrixF: List[Future[CorrMapping]] = (for (i <- stocks.indices;
                                                   j <- (i + 1) until stocks.size)
      yield {
        Future[CorrMapping] {
          val s1 = stockIds(i)
          val s2 = stockIds(j)
          val corr = priceCorr(stocks(i), stocks(j))
          (s1, s2) -> corr
        }
      }).toList
    val matrix: List[CorrMapping] = Await
      .ready(matrixF.sequence[Future, CorrMapping], Duration.Inf)
      .value
      .get
      .get

    val pearsonMatrix: List[((String, String), (Double, Double))] =
      matrix.map(tup => (tup._1, tup._2._1))
    println("Pearson相关系数如下：")
    showSingleCorrelation(pearsonMatrix)
    println("------------------------------")

    val spearmanMatrix: List[((String, String), (Double, Double))] =
      matrix.map(tup => (tup._1, tup._2._2))
    println("Spearman相关系数如下：")
    showSingleCorrelation(spearmanMatrix)
    println("------------------------------")

    println("End time: " + LocalTime.now())
  }

  private def showSingleCorrelation(
    matrix: List[((String, String), (Double, Double))]
  ): Unit = {
    val sorted = matrix.sortBy(x => math.abs(x._2._1))
    val min5 = sorted.take(5)
    val max5 = sorted.takeRight(5).reverse
    println("相关性最强的5对：")
    def printPair(p: ((String, String), (Double, Double))): Unit = {
      println(s"(${p._1._1}, ${p._1._2}) -> 相关系数: ${p._2._1}，P值：${p._2._2}")
    }
    max5.foreach(printPair)

    println("相关性最弱的5对：")
    min5.foreach(printPair)
  }

  private def listCSVFiles(): IndexedSeq[File] = {
    val currentDir = new File(getClass.getResource(".").getPath)
    currentDir
      .listFiles(new FilenameFilter {
        override def accept(dir: File, name: String): Boolean =
          name.endsWith(".csv")
      })
      .sortBy(_.getName)
  }

  private def readStocks(csvFiles: IndexedSeq[File]) = {
    csvFiles
      .map(f => {
        val reader = CSVReader.open(f)
        val result = reader.toStreamWithHeaders
          .map(
            line =>
              (
                LocalDate.parse(line("date")),
                (line("high").toDouble + line("low").toDouble) / 2.0
            )
          )
          .toMap
        reader.close()
        result
      })
      .toIndexedSeq
  }

  /**
    * Computes pearson and spearman correlation coefficient of
    * price of two stocks
    *
    * @param stock1 one stock
    * @param stock2 another stock
    * @return (pearson, spearman, p-val)
    */
  def priceCorr(
    stock1: Map[LocalDate, Double],
    stock2: Map[LocalDate, Double]
  ): ((Double, Double), (Double, Double)) = {
    val commonDates = stock1.keySet.intersect(stock2.keySet)
    val pricePair: Seq[(Double, Double)] =
      commonDates.map(date => (stock1(date), stock2(date))).toSeq
    (Correlation.pearson(pricePair), Correlation.spearman(pricePair))
  }
}
