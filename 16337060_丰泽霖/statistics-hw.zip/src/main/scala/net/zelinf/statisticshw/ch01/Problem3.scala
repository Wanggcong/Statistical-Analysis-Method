package net.zelinf.statisticshw.ch01

import com.github.tototoshi.csv.CSVReader
import net.zelinf.statisticshw.ch01.impl.Correlation
import MatlabHelper.engine

object Problem3 {

  def main(args: Array[String]): Unit = {
    var reader: CSVReader = null
    try {
      reader = CSVHelper.readerFromFileInClasspath("000012.csv", getClass)
      val data = reader.toStreamWithHeaders
      val prices = CSVHelper.prices(data)
      val volume = CSVHelper.column(data, "volume")

      val priceVolume = prices.zip(volume)
      val r1 = Correlation.pearson(priceVolume)
      println(s"Pearson 相关系数：${r1._1}")
      val r2 = Correlation.spearman(priceVolume)
      println(s"Spearman 相关系数：${r2._1}")

    } finally {
      if (reader != null)
        reader.close()
    }

  }
}
