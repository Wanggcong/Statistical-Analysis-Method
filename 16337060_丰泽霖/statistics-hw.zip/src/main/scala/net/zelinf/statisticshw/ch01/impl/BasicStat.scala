package net.zelinf.statisticshw.ch01.impl
import com.mathworks.engine.MatlabEngine

object BasicStat {

  def mean(xs: Traversable[Double]): Double = {
    require(xs.nonEmpty)
    xs.sum / xs.size
  }

  def median(xs: IndexedSeq[Double]): Double = {
    require(xs.nonEmpty)
    val xs_ = xs.sorted
    val size = xs_.size
    if (size % 2 != 0) {
      xs_(size / 2)
    } else {
      (xs_(size / 2 - 1) + xs_(size / 2)) / 2
    }
  }

  private def quarterQuant(xs: IndexedSeq[Double], n: Int): Double = {
    require(xs.nonEmpty)
    val xs_ = xs.sorted

    val size = xs_.size
    val j = size * n / 4
    if (size % 4 != 0) {
      xs_(j)
    } else {
      (xs_(j) + xs_(j - 1)) / 2
    }
  }

  def quarterUpperQuant(xs: IndexedSeq[Double]): Double = {
    quarterQuant(xs, 3)
  }

  def quarterLowerQuant(xs: IndexedSeq[Double]): Double = {
    quarterQuant(xs, 1)
  }

  def variance(xs: IndexedSeq[Double]): Double =
    xs.zip(Array.fill(xs.size)(xs.mean))
      .view
      .map(tup => tup._1 - tup._2)
      .map(x => x * x)
      .sum / (xs.size - 1)

  def stdDeviation(xs: IndexedSeq[Double]): Double =
    math.sqrt(variance(xs))

  def cv(xs: IndexedSeq[Double]): Double =
    100 * xs.stdDeviation / xs.mean

  def range(xs: IndexedSeq[Double]): Double =
    xs.max - xs.min

  def quarterQuantRange(xs: IndexedSeq[Double]): Double =
    xs.quarterUpperQuant - xs.quarterLowerQuant

  def skewness(xs: IndexedSeq[Double]): Double =
    xs.size.toDouble / ((xs.size - 1).toDouble * (xs.size - 2)) * (xs
      .zip(IndexedSeq.fill(xs.size)(xs.mean))
      .map(tup => tup._1 - tup._2)
      .map(x => x * x * x)
      .sum / math.pow(xs.stdDeviation, 3))

  def kurtosis(
    xs: IndexedSeq[Double]
  )(implicit engine: MatlabEngine): Double = {
    val mean = xs.mean
    val n = xs.length.toDouble
    n * (n + 1) / ((n - 1) * (n - 2) * (n - 3)) * (1 / math.pow(
      stdDeviation(xs),
      4
    )) *
      xs.zip(IndexedSeq.fill(xs.size)(mean))
        .map(tup => tup._1 - tup._2)
        .map(math.pow(_, 4))
        .sum -
      (3 * math.pow(n - 1, 2)) / ((n - 2) * (n - 3))
  }

  implicit class BasicStatOps(xs: IndexedSeq[Double]) {
    def mean: Double = BasicStat.mean(xs)
    def median: Double = BasicStat.median(xs)
    def quarterUpperQuant: Double = BasicStat.quarterUpperQuant(xs)
    def quarterLowerQuant: Double = BasicStat.quarterLowerQuant(xs)
    def variance: Double = BasicStat.variance(xs)
    def stdDeviation: Double = BasicStat.stdDeviation(xs)
    def cv: Double = BasicStat.cv(xs)
    def range: Double = BasicStat.range(xs)
    def quarterQuantRange: Double = BasicStat.quarterQuantRange(xs)
    def skewness: Double = BasicStat.skewness(xs)
    def kurtosis(implicit engine: MatlabEngine): Double = BasicStat.kurtosis(xs)
  }

}
